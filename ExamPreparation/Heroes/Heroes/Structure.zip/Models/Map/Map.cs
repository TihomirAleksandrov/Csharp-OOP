﻿using Heroes.Models.Contracts;
using Heroes.Models.Heroes;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Heroes.Models.Map
{
    public class Map : IMap
    {
        public string Fight(ICollection<IHero> players)
        {
            var knights = new List<IHero>();
            var barbarians = new List<IHero>();

            SeparateHeroes(players, knights, barbarians);

            while (knights.Any(x => x.IsAlive) && barbarians.Any(x => x.IsAlive))
            {
                foreach(var knight in knights)
                {
                    foreach (var barbarian in barbarians)
                    {
                        if (barbarian.IsAlive)
                        {
                            barbarian.TakeDamage(knight.Weapon.DoDamage());
                        }
                    }
                }

                foreach(var barbarian in barbarians)
                {
                    foreach(var knight in knights)
                    {
                        if (knight.IsAlive)
                        {
                            knight.TakeDamage(barbarian.Weapon.DoDamage());
                        }
                    }
                }
            }

            if(knights.Any(x => x.IsAlive))
            {
                return $"The knights took {knights.Where(x => !x.IsAlive).ToList().Count} casualties but won the battle.";
            }
            return $"The barbarians took {knights.Where(x => !x.IsAlive).ToList().Count} casualties but won the battle.";
        }

        private void SeparateHeroes(ICollection<IHero> players, List<IHero> knights, List<IHero> barbarians)
        {
            foreach (var hero in players)
            {
                if (hero is Knight)
                {
                    knights.Add(hero);
                }
                else
                {
                    barbarians.Add(hero);
                }
            }
        }
    }
}
