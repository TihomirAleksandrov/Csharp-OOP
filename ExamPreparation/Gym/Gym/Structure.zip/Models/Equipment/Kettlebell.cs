﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gym.Models.Equipment
{
    public class Kettlebell : Equipment
    {
        public Kettlebell(double weight, decimal price) : base(1000, 80m)
        {

        }
    }
}
