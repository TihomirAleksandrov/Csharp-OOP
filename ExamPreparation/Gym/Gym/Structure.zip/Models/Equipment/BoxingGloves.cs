﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gym.Models.Equipment
{
    public class BoxingGloves : Equipment
    {
        public BoxingGloves(double weight, decimal price) : base(227, 120m)
        {

        }
    }
}
