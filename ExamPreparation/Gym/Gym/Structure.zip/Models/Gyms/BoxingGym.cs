﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gym.Models.Gyms
{
    public class BoxingGym : Gym
    {
        public BoxingGym(string name, int capacity) : base(name, 15)
        {

        }
    }
}
