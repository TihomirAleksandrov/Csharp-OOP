﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gym.Models.Gyms
{
    public class WeightliftingGym : Gym
    {
        public WeightliftingGym(string name, int capacity) : base(name, 20)
        {

        }
    }
}
