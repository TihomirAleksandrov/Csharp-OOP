﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BookingApp.Models.Rooms
{
    public class Apartment : Room
    {
        public Apartment(int bedCapacity) : base(6)
        {
        }
    }
}
